# 推荐阅读

## 本书推送贴的留言和讨论
- v2ex: http://www.v2ex.com/t/267557
- 微博长文: http://weibo.com/1054764633/DoN6Z5Haq?type=repost

## v2ex网友florije推荐
- 另外一本同名IntermediatePython的更新的书  https://leanpub.com/intermediatepython

## v2ex网友xiaket推荐
- 对于Python提高类的书，推荐Fluent Python 或 Pro Python

## v2ex网友shishen10 推荐
- 老齐的教程 https://github.com/qiwsir/StarterLearningPython
- 老齐还整理了很多精华 https://github.com/qiwsir/ITArticles

## v2ex网友xiaowangge推荐
[Yixiaohan](https://github.com/Yixiaohan)整理了一个不错的推荐：[Python初学者（零基础学习Python、Python入门）书籍、视频、资料、社区推荐](https://github.com/Yixiaohan/codeparkshare)大家可以前去Fork。

## v2ex推荐学习书目

- [Learn Python the Hard Way](http://learn-python-the-hard-way-zh_cn-translation.readthedocs.org/en/1.0/)
- [Python 学习手册-第五版中文版](https://www.gitbook.com/book/yulongjun/learning-python-in-chinese/details) 
- [Python Cookbook](http://python3-cookbook.readthedocs.org/zh_CN/latest/)
- [Python 基础教程](https://book.douban.com/subject/4866934/)
