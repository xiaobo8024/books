# 迭代器(Iterator)

任意对象，只要定义了```next```(Python2) 或者```__next__```方法，它就是一个迭代器。就这么简单。现在我们来理解迭代(iteration)
