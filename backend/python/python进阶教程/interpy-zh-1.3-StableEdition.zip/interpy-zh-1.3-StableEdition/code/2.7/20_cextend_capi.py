import addList

l = [1,2,3,4,5]
print 'Sum of list - ', str(l), '=', str(addList.add(l))
