
foo = ['hi']
print foo

bar = foo
bar += ['bye']
print foo
