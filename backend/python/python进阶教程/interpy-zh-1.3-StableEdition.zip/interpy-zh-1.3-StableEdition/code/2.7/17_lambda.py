add = lambda x, y: x + y
print add(4,6)
